MATTHEW AZER ENGINEERING PORTFOLIO

1. Upload index.html, style.css, and script.js to the ROOT of your mazerw2.github.io repository.
2. Replace the temporary index.html file when uploading these.
3. Visit https://mazerw2.github.io after GitHub Pages finishes publishing.
4. Add a resume.pdf at the ROOT of the repository to make both Resume buttons work.
5. Replace the robot illustration with your own photo/video, and check every project and work-experience description for accuracy.
6. Add your LinkedIn and professional contact email before sending to employers.
7. When satisfied, configure matthewazer.com through GitHub Pages Settings and Namecheap Advanced DNS.

NOTE: This site uses Google Fonts; if you're offline it falls back to locally installed fonts.
